
setwd("/media/yanglu/TOSHIBA/deepknockoff/data/2018-03-18/microbiome/data")
source('/media/yanglu/OS/Users/isaac/Documents/deepknockoff/src/RANK/gknockoff_all.R')
source('/media/yanglu/OS/Users/isaac/Documents/deepknockoff/src/RANK/isee_all.R')



require(graphics)
#library(igraph)
library(MASS)
library(Matrix)
library(pracma)

library(foreach)
library(glmnet)
library(lars)
library(scalreg)

regfactor = "log"
npermu = 5
sis.use = 0
bia.cor = 0
q=0.2

typeList = c('Z')

epochList = c(10,20,30)
resultTypeList = c('_v5')



headerList = c()
headerURL = "miocrobiome_cenlograc_header.txt"
conn <- file(headerURL,open="r")
linn <-readLines(conn)
for (i in 1:length(linn)){
   headerList = append(headerList, linn[i])
}
close(conn)
headerList = gsub("\"", "", headerList)
#print(headerList)


for (type in typeList) {
for (epoch in epochList) {

print("================================================================");
print(paste("epoch = ",toString(epoch)))
print("================================================================");

for (resultType in resultTypeList) {

resultURL = paste(type,"/","result_2layer_epoch100_batch10_biasTrue_actrelu_filt1_2local_eqInitMLPRegCoeff1Div1000_ES", "/result_epoch", toString(epoch), toString(resultType), ".csv",sep="")
print(resultURL)
outputURL = paste(type,"/","result_2layer_epoch100_batch10_biasTrue_actrelu_filt1_2local_eqInitMLPRegCoeff1Div1000_ES", "/taxa_epoch", toString(epoch), toString(resultType), ".csv",sep="")


resultMat <- read.csv(resultURL, header = FALSE, sep = ",")
repAll <- nrow(resultMat); p1 <- ncol(resultMat); p <- floor(p1/2);
print(paste("p=",toString(p)," p1=",toString(p1)," resultType=",toString(resultType)," type=",toString(type)))

combinedInRepList = c()
for(repNum in 1:repAll) {
betap.stan = unlist(resultMat[repNum,])
W = c(rep(0, p))
for (j in 1:p) {
  W[j] = abs(betap.stan[j]) - abs(betap.stan[j+p])
}

t = sort(c(0, abs(W)))
ratio = c(rep(0, p))
for (j in 1:p) {
  ratio[j] = sum(W <= -t[j])/max(1, sum(W >= t[j]))
}


id = which(ratio <= q)[1]
if(length(id) == 0){
  T = Inf
} else {
  T = t[id]
}

S = which(W >= T);
#print(paste(S, collapse = ', '))
combinedInRepList = append(combinedInRepList, S)
}
uniqCombinedInRepList = sort(unique(combinedInRepList));
uniqCombinedInRepList_cutoff = c();
outputList = c();
for (uniqVal in uniqCombinedInRepList) {
   cnt = length(combinedInRepList[combinedInRepList==uniqVal]);
   if (cnt > 1) {
      uniqCombinedInRepList_cutoff = append(uniqCombinedInRepList_cutoff, uniqVal);
      outputList = append(outputList, paste(headerList[uniqVal],toString(cnt),sep="\t"))
   }
}

uniqHeaderInRepList_cutoff = headerList[uniqCombinedInRepList_cutoff];
print(uniqHeaderInRepList_cutoff)

outputConn<-file(outputURL)
writeLines(outputList, outputConn)
close(outputConn)

}
}

}



