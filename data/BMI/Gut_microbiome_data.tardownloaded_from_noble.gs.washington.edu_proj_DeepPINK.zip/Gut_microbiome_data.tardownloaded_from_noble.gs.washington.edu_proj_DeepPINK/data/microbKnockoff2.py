import time
import math
import sys
import os

import numpy as np
import pandas as pd
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
from scipy.linalg import qr

import keras
from keras.models import Sequential, Model, model_from_json
from keras.layers import Input, Dense, Dropout, BatchNormalization, merge, LocallyConnected1D, Flatten, Conv1D
from keras import backend as K
from keras import regularizers
from keras.objectives import mse
from keras import regularizers, optimizers
from keras.callbacks import EarlyStopping
from keras.initializers import Constant

from sklearn.preprocessing import StandardScaler


dataDir = '/media/ylu465/Data/deepknockoff/data/2018-03-18/microbiome/data';

typeList = ['X','Xsub','XsubZ','XZ','Z']
batchNumList = [1,5,10,20,50];


epochNum = 200;
filterNum = 1;
bias = True
activation='relu'

def show_layer_info(layer_name, layer_out):
    print('[layer]: %s\t[shape]: %s \n' % (layer_name,str(layer_out.get_shape().as_list())))



def getModel(p, coeff):
    model = Sequential()
    model.add(Dense(p, activation='relu',use_bias=True, kernel_initializer='glorot_normal', kernel_regularizer=regularizers.l1(coeff), input_dim=p))
    model.add(Dense(p, activation='relu',use_bias=True, kernel_initializer='glorot_normal', kernel_regularizer=regularizers.l1(coeff)))
    # model.add(Dense(p, activation='relu',use_bias=True, kernel_initializer='glorot_normal', kernel_regularizer=regularizers.l1(1.0)))

    model.add(Dense(1, kernel_initializer='glorot_normal'))
    model.compile(loss='mse', optimizer='adam')
    return model



def getModel3DLocal(p, filterNum, coeff):

    input = Input(name='input', shape=(p, 2));
    show_layer_info('Input', input);

    local1 = LocallyConnected1D(filterNum,1, use_bias=bias, kernel_initializer='glorot_normal')(input);
    show_layer_info('LocallyConnected1D', local1);

    local2 = LocallyConnected1D(1,1, use_bias=bias, kernel_initializer='glorot_normal')(local1);
    show_layer_info('LocallyConnected1D', local2);

    flat = Flatten()(local2);
    show_layer_info('Flatten', flat);

    dense1 = Dense(p, activation=activation,use_bias=bias, kernel_initializer='glorot_normal', kernel_regularizer=regularizers.l1(coeff))(flat);
    show_layer_info('Dense', dense1);

    dense2 = Dense(p, activation=activation, use_bias=bias, kernel_initializer='glorot_normal', kernel_regularizer=regularizers.l1(coeff))(dense1);
    show_layer_info('Dense', dense2);

    out_ = Dense(1, kernel_initializer='glorot_normal')(dense2)
    show_layer_info('Dense', out_)

    model = Model(inputs=input, outputs=out_)
    model.compile(loss='mse', optimizer='adam')
    return model


def getModel3DLocalEq(p, filterNum, coeff):

    input = Input(name='input', shape=(p, 2));
    show_layer_info('Input', input);

    local1 = LocallyConnected1D(filterNum,1, use_bias=bias, kernel_initializer=Constant(value=0.1))(input);
    show_layer_info('LocallyConnected1D', local1);

    local2 = LocallyConnected1D(1,1, use_bias=bias, kernel_initializer='glorot_normal')(local1);
    show_layer_info('LocallyConnected1D', local2);

    flat = Flatten()(local2);
    show_layer_info('Flatten', flat);

    dense1 = Dense(p, activation=activation,use_bias=bias, kernel_initializer='glorot_normal', kernel_regularizer=regularizers.l1(coeff))(flat);
    show_layer_info('Dense', dense1);

    dense2 = Dense(p, activation=activation, use_bias=bias, kernel_initializer='glorot_normal', kernel_regularizer=regularizers.l1(coeff))(dense1);
    show_layer_info('Dense', dense2);

    out_ = Dense(1, kernel_initializer='glorot_normal')(dense2)
    show_layer_info('Dense', out_)

    model = Model(inputs=input, outputs=out_)
    model.compile(loss='mse', optimizer='adam')
    return model


class My_Callback(keras.callbacks.Callback):
    def __init__(self, outputDir):
        self.outputDir = outputDir;
        print(self.outputDir)


    def on_epoch_end(self, epoch, logs={}):
        if ((epoch+1) % 10) != 0: return;

        h_local1_weight = np.array(self.model.layers[1].get_weights()[0]);
        h_local2_weight = np.array(self.model.layers[2].get_weights()[0]);

        print('h_local1_weight = ' + str(h_local1_weight.shape))
        print('h_local2_weight = ' + str(h_local2_weight.shape))
        h0 = np.zeros((pVal, 2));
        h0_abs = np.zeros((pVal, 2));

        for pIdx in range(pVal):
            h0[pIdx, :] = np.matmul(h_local1_weight[pIdx, :, :], h_local2_weight[pIdx, :, :]).flatten();
            h0_abs[pIdx, :] = np.matmul(np.fabs(h_local1_weight[pIdx, :, :]), np.fabs(h_local2_weight[pIdx, :, :])).flatten();

        print('h0 = ' + str(h0.shape))
        print('h0_abs = ' + str(h0_abs.shape))

        h1 = np.array(self.model.layers[4].get_weights()[0]);
        h2 = np.array(self.model.layers[5].get_weights()[0]);
        h3 = np.array(self.model.layers[6].get_weights()[0]);

        print('h1 = ' + str(h1.shape))
        print('h2 = ' + str(h2.shape))
        print('h3 = ' + str(h3.shape))

        W1 = h1;
        W_curr = h1;
        W2 = np.matmul(W_curr, h2);
        W_curr = np.matmul(W_curr, h2);
        W3 = np.matmul(W_curr, h3);

        print('W1 = ' + str(W1.shape))
        print('W2 = ' + str(W2.shape))
        print('W3 = ' + str(W3.shape))
        v0_h0_abs = h0_abs[:, 0].reshape((pVal, 1));
        v1_h0_abs = h0_abs[:, 1].reshape((pVal, 1));

        v1 = np.vstack((v0_h0_abs, v1_h0_abs)).T;
        v2 = np.vstack((np.sum(np.multiply(v0_h0_abs, np.fabs(W2)), axis=1).reshape((pVal, 1)), np.sum(np.multiply(v1_h0_abs, np.fabs(W2)), axis=1).reshape((pVal, 1)))).T;
        v3 = np.vstack((np.sum(np.multiply(v0_h0_abs, np.fabs(W3)), axis=1).reshape((pVal, 1)), np.sum(np.multiply(v1_h0_abs, np.fabs(W3)), axis=1).reshape((pVal, 1)))).T;

        v4 = np.vstack((np.sum(np.square(np.multiply(v0_h0_abs, np.fabs(W2))), axis=1).reshape((pVal, 1)), np.sum(np.square(np.multiply(v1_h0_abs, np.fabs(W2))), axis=1).reshape((pVal, 1)))).T;
        v5 = np.vstack((np.sum(np.square(np.multiply(v0_h0_abs, np.fabs(W3))), axis=1).reshape((pVal, 1)), np.sum(np.square(np.multiply(v1_h0_abs, np.fabs(W3))), axis=1).reshape((pVal, 1)))).T;

        v6 = np.vstack((np.max(np.multiply(v0_h0_abs, np.fabs(W2)), axis=1).reshape((pVal, 1)), np.sum(np.multiply(v1_h0_abs, np.fabs(W2)), axis=1).reshape((pVal, 1)))).T;
        v7 = np.vstack((np.max(np.multiply(v0_h0_abs, np.fabs(W3)), axis=1).reshape((pVal, 1)), np.sum(np.multiply(v1_h0_abs, np.fabs(W3)), axis=1).reshape((pVal, 1)))).T;

        with open(os.path.join(outputDir, 'result_epoch'+ str(epoch+1) +'_v1.csv'), "a+") as myfile:
            myfile.write(','.join([str(x) for x in v1.flatten()]) + '\n');
        with open(os.path.join(outputDir, 'result_epoch'+ str(epoch+1) +'_v2.csv'), "a+") as myfile:
            myfile.write(','.join([str(x) for x in v2.flatten()]) + '\n');
        with open(os.path.join(outputDir, 'result_epoch'+ str(epoch+1) +'_v3.csv'), "a+") as myfile:
            myfile.write(','.join([str(x) for x in v3.flatten()]) + '\n');
        with open(os.path.join(outputDir, 'result_epoch'+ str(epoch+1) +'_v4.csv'), "a+") as myfile:
            myfile.write(','.join([str(x) for x in v4.flatten()]) + '\n');
        with open(os.path.join(outputDir, 'result_epoch'+ str(epoch+1) +'_v5.csv'), "a+") as myfile:
            myfile.write(','.join([str(x) for x in v5.flatten()]) + '\n');


for batchNum in batchNumList:
    for type in typeList:
        x_url = os.path.join(dataDir, type, type + '_knockoff.csv')
        y_url = os.path.join(dataDir, type, 'Y.csv');
        print(x_url);
        print(y_url);

        yvalues = pd.read_csv(y_url, header=None).values.astype(float);
        xvalues = pd.read_csv(x_url, header=None).values.astype(float);

        print(xvalues.shape)
        print(yvalues.shape)

        n = xvalues.shape[0];
        pVal = int(xvalues.shape[1]/2);
        print('pVal = '+str(pVal))

        X_origin = xvalues[:, 0:pVal];
        X_knockoff = xvalues[:, pVal:];

        x3D = np.zeros((n, pVal, 2));
        x3D[:, :, 0] = X_origin;
        x3D[:, :, 1] = X_knockoff;

        coeff1 = np.sqrt(2.0 * np.log(pVal) / n);
        outputDir = os.path.join(dataDir, type, 'result_2layer_epoch' + str(epochNum) + '_batch' + str(batchNum) + '_bias' + str(bias) + '_act' + str(activation) + '_filt' + str(filterNum) + '_2local_eqInitMLPRegcoeff1_ES');

        try:
            os.stat(outputDir)
        except:
            os.mkdir(outputDir)

        for iter in range(1, 6, 1):
            print('iter=' + str(iter));
            np.random.seed(iter);

            myCallback = My_Callback(outputDir);
            model3D = getModel3DLocalEq(pVal, filterNum, coeff1);
            model3D.fit(x3D, yvalues, epochs=epochNum, batch_size=batchNum, verbose=1, callbacks=[myCallback]);

