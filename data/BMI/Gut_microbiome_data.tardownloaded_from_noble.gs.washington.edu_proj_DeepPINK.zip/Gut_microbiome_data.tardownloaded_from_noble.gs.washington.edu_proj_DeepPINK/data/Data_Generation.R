setwd("/media/yanglu/TOSHIBA/deepknockoff/data/2018-03-18/microbiome/data") 
count = read.table('combo_count_tab.txt')
length(count[1,])

%microbiome
count <- as.matrix(read.table("combo_count_tab.txt"))
depth <- sapply(strsplit(colnames(count), "\\."), length)
x <- count[, depth == 6 & colSums(count != 0) >= 1]
x[x == 0] <- 0.5
p = dim(x)
colnames(x)

%new approach

log_x <- log(x)
gm_x <- exp(rowSums(log_x)/p[2])
z <- x/gm_x 
z <- log(z)


%using log(x_i/x_p)

%x <- x[,1:(p[2]-1)]/x[,p[2]] 
%z <- log(x)
%x <- x/rowSums(x)
%z <- log(x) %log(x_i)

%nutrient intake & BMI
setwd("/media/yanglu/TOSHIBA/deepknockoff/data/2018-03-18/microbiome/data")
load("combo.RData")
X = ffq.adj
X1 = ffq.raw
colnames(X)
y = bmi.c


n = dim(X)
dim(t(X))

%demo <- read.delim("data/demographic.txt")
%y <- demo$bmi[match(rownames(count), demo$pid)]

write.table(X, file = "nutrient intake.txt", append = T, col.names = F, row.names = F)
write.table(X1, file = "nutrient_intake_raw.txt", append = T, col.names = F, row.names = F)
write.table(y, file = "bmi.txt", append = T, col.names = F, row.names = F)
write.table(z, file = "miocrobiome_cenlograc.txt", append = T, col.names = F, row.names = F)
%write.table(z, file = "miocrobiome_log.txt", append = T, col.names = F, row.names = F)

177 uapig: Apigenin, flavone
10  magn: Magnesium
185 ugcat: Gallocatechin, flavan-3-ol
194 upel:  Pelargonidin, anthocyanidin
162 dvitk: Dihydrophylloquinone Vitamin K1

182 uerid: Eriodictyol, flavonone 
129 brann: Natural Brans

36 sodium: Sodium
33 b12: Vitamin B12
131 germa: Added Germ from wheats
53 f180: Stearic fatty acid
166 aspart: Aspartame fort. foods

55 f201: Eicosenoic fatty acid
67 b2_wo: Riboflavin B2 w/o vit. pills
167 acryl: Acrylamide
181 unarg: Naringenin, flavanone


50 f120: Lauric fatty acid
86 es2mg: Vitamin E,  Food Fortification
164 phenyla: Phenylalanine, Aspartame

 [1] ".Random.seed"  "abund.list"    "BC"            "BC.rff"       
 [5] "bmi.c"         "demo"          "enterotype"    "ffq.adj"      
 [9] "ffq.label"     "ffq.raw"       "fungi.otu.tab" "otu.names.mat"
[13] "otu.tab"       "otu.tab.rff"   "tree"          "tree.rooted"  
[17] "unifracs"      "unifracs.rff" 
