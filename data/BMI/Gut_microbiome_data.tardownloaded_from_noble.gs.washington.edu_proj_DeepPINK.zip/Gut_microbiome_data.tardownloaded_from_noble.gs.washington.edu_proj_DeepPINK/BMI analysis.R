setwd("C:/Users/Administrator/Desktop/MFknockoff")
source('gknockoff_all.R')
source('isee_all.R')

require(graphics)
library(igraph)
library(MASS) 
library(Matrix)
library(pracma)

library(foreach)
library(glmnet)
library(lars)
library(scalreg)
library(RJSONIO)

set.seed(100)

Xdataraw = as.matrix(read.table("data/nutrient_intake.txt"))
Zdataraw = as.matrix(read.table("data/miocrobiome_cenlograc.txt"))
ydataraw = as.matrix(read.table("data/bmi.txt"))

#remove the outlier
set = union(1:17,19:98)
#focus on the non-thin ones
set = setdiff(set, which(ydataraw - mean(ydataraw)< -6))
Xdata = Xdataraw[set,]
Zdata = Zdataraw[set,]
ydata = t(t(ydataraw[set]))
#dim(ydata)

n = nrow(Xdata)
p = ncol(Xdata)

#remove high correlations
R = cor(Xdata)
L = lower.tri(R, diag = T)
R[L] = 0
sub = c()
for (i in 1:(p - 1)) {
   if (is.element(i, sub)){}
   else
     {sub = union(sub, which(R[i,] > 0.9))}
}
supp = setdiff(1:p, sub)
Xdata = Xdata[,supp]
Xdata = cbind(matrix(1, nrow = n, ncol = 1), Xdata)
p = ncol(Xdata)

#bootstrap
nsam = n
K = 20
numsplit = 100

#Latent factors as PC
Z = Zdata
eigZ = eigen(t(Z)%*%Z)
EZ = eigZ$vectors[,2:K]
EPC = Z%*%EZ

#MF-knockoffs
q = 0.2
pf = p + K - 1
indmat = matrix(0, nrow = numsplit, ncol = p)
indfmat = matrix(0, nrow = numsplit, ncol = pf)
    
for (ii in 1:numsplit){
print(ii) 
bootid = sample(nsam, replace = TRUE)
y = t(t(ydata[bootid]))
X = Xdata[bootid,]
Xsca = sqrt(colSums(X*X))/sqrt(nsam)
X = X/(matrix(1, nrow = nsam, ncol = 1)%*%Xsca)
EPCb = EPC[bootid,] 
Esca = sqrt(colSums(EPCb*EPCb))/sqrt(nsam)
EPCb = EPCb/(matrix(1, nrow = nsam, ncol = 1)%*%Esca)
Xf = cbind(X,EPCb)


#graphical knockoff filter to compute the FDR and Power with unknown Omega
obj_S = gknockoff_unknown(X, y, q, regfactor = "log")
S = obj_S$S

obj_Sf = gknockoff_unknown(Xf, y, q, regfactor = "log")
Sf = obj_Sf$S

indmat[ii,S] = 1
indfmat[ii,Sf] = 1
}

selprob_kf = colSums(indmat)/numsplit
s = sort(selprob_kf,decreasing=T,index.return=TRUE)
s$x[1:10]
supp[s$ix[2:10] - 1]
    
selprob_kfl = colSums(indfmat)/numsplit
sf = sort(selprob_kfl,decreasing=T,index.return=TRUE)
sf$x[1:10]
sf$ix[1:10]







