function id = mspbs(X, y, betav)

% prediction-based selection

[nrow p] = size(betav);
PEvec = mean((y*ones(1, p) - X*betav).^2);
[PEval id] = min(PEvec);
