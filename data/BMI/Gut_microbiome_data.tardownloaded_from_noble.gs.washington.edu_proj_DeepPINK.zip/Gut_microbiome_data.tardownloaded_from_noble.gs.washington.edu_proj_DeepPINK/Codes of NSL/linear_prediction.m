%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
warning off all

%seed_ini = 100;
seed_ini = 200;
randn('state', seed_ini); % set the state of randn (Gaussian)
rand('state', seed_ini); % set the state of rand (uniform)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load the dataset

Xdataraw = importdata('data\nutrient intake.txt');
Zdataraw = importdata('data\miocrobiome_cenlograc.txt');
ydataraw = importdata('data\bmi.txt');

%remove the outlier
set = [1:17,19:98];
%focus on the non-thin ones
set = setdiff(set, find(ydataraw - mean(ydataraw)< -6));
Xdata = Xdataraw(set,:);
Zdata = Zdataraw(set,:);
ydata = ydataraw(set);

[n p] = size(Xdata);

%remove high correlations
R = corrcoef(Xdata);
T = triu(R,1);
sub = [];
for i = 1:(p - 1)
    if ismember(i, sub)
    else
        sub = union(sub, find(T(i,:)> 0.9));
    end
end
supp = setdiff(1:p, sub);
Xdata = Xdata(:,supp);
Xdata = [ones(size(Xdata(:, 1))) Xdata];

[n p] = size(Xdata);
    
%prediction

K = 20;
numsplit = 100;
n_train = 60;

% Latent factors as PC

Z = Zdata;
[EZ,ED] = eig(Z'*Z);
ED = diag(ED);
[ED,I] = sort(ED,'descend');
EZ = EZ(:,I(2:K));
EPCdata = Z*EZ;


Xsca = sqrt(sum(Xdata.^2))/sqrt(n);
X = Xdata./(ones(n, 1)*Xsca);
Esca = sqrt(sum(EPCdata.^2))/sqrt(n);
EPC = EPCdata./(ones(n, 1)*Esca);
   

y = ydata;
Xf = [X,EPC];
delta = 0.01;


    
for ii = 1:numsplit
    ii
    
    ind = randperm(n);
    ind_train = ind(1:n_train);
    ind_test = setdiff(1:n, ind_train);
    
    X_train = X(ind_train, :);
    Xf_train = Xf(ind_train, :);
    y_train = y(ind_train);
    
    X_test = X(ind_test, :);
    Xf_test = Xf(ind_test, :);
    y_test = y(ind_test);
    
    %Enet   
    [betap_enet info_enet] = elasticnet(X_train, y_train, delta);
    [betap_enetf info_enetf] = elasticnet(Xf_train, y_train, delta);
   
    
    % validation set
    id = mspbs(X_train, y_train, betap_enet);
    idf = mspbs(Xf_train, y_train, betap_enetf);
    betamat_enet_vs(ii, :) = betap_enet(:, id);
    betamat_enetf_vs(ii, :) = betap_enetf(:, idf);
    
    % Prediction error 
    
    PE_enet(ii) = mean((y_test - X_test*betamat_enet_vs(ii, :)').^2);
    PE_enetf(ii) = mean((y_test - Xf_test*betamat_enetf_vs(ii, :)').^2);

      
    save prediction_enet.mat
end

   
clear all
close all
load prediction_enet.mat

format short

mean(PE_enet)
mean(PE_enetf)

std(PE_enet)
std(PE_enetf)

% median model size

modsiz_enet_vs = median(sum(betamat_enet_vs~=0,2))
modsiz_enetf_vs = median(sum(betamat_enetf_vs~=0,2))

% selection probabilities for Enet
selprob_enet_vs = mean(betamat_enet_vs~=0,1);
effect_enet_vs = mean(betamat_enet_vs,1);
[L,iL] = sort(selprob_enet_vs,'descend');
L(1:10)
supp(iL(2:10) - 1)
effect_enet_vs(iL(1:10))

selprob_enetf_vs = mean(betamat_enetf_vs~=0,1);
effect_enetf_vs = mean(betamat_enetf_vs,1);
[Lf,iLf] = sort(selprob_enetf_vs,'descend');
Lf(1:10)
iLf(1:10)
effect_enetf_vs(iLf(1:10))

supp(iL(11:20) - 1)
selprob_enetf_vs(iL(11:20))
effect_enetf_vs(iL(11:20))

