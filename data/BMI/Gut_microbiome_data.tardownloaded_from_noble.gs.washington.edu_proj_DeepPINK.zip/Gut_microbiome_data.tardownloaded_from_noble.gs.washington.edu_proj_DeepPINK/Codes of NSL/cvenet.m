function [idreturn APE] = cvenet(X, y, delta, lamvec, nfold, seed)

if (nargin == 6)
    randn('state', seed);
    rand('state', seed);
end
if (nargin < 5) nfold = 5; end

[n p] = size(X);

newid = randperm(n);
Xnew = X(newid, :);
M = length(lamvec);

for j = 1:M
for k = 1:nfold
    clear colnum betamat0
    colnum=newid(((k-1)*floor(n/nfold)+1):(min(k*floor(n/nfold),n)));
    Xtrain = X(setdiff(1:n,colnum),:);
    Xtest = X(colnum,:);
    
    ytrain=y(setdiff(1:n,colnum));
    ytest=y(colnum);
    
    betamat0 = elasticnet(Xtrain, ytrain, delta, lamvec(j), false);
    PE(k,j) = mean((ytest - Xtest*betamat0).^2);
end

end

PEtotal=mean(PE,1);
[B,id]=min(PEtotal);

if (nargout == 1)
    idreturn=id;
elseif (nargout == 2)
    idreturn=id;
    APE=min(B);
end