setwd("/home/yanglu/Documents/deepknockoff/data/2018-03-18/microbiome")


source('/home/yanglu/Documents/deepknockoff/src/RANK/gknockoff_all.R')
#source('/home/yanglu/Documents/deepknockoff/src/RANK/gknockoff_all_emre.R')
source('/home/yanglu/Documents/deepknockoff/src/RANK/isee_all.R')


require(graphics)
library(igraph)
library(MASS) 
library(Matrix)
library(pracma)

library(foreach)
library(glmnet)
library(lars)
library(scalreg)

set.seed(100)

Xdataraw = as.matrix(read.table("data/nutrient_intake.txt"))
Zdataraw = as.matrix(read.table("data/miocrobiome_cenlograc.txt"))
ydataraw = as.matrix(read.table("data/bmi.txt"))

#remove the outlier
set = union(1:17,19:98)
#focus on the non-thin ones
set = setdiff(set, which(ydataraw - mean(ydataraw)< -6))
Xdata = Xdataraw[set,]
Zdata = Zdataraw[set,]
ydata = t(t(ydataraw[set]))
#dim(ydata)

n = nrow(Xdata)
p = ncol(Xdata)

q = 0.2
K = 20
regfactor = "log"
npermu = 5
sis.use = 0
bia.cor = 0


#Latent factors as PC
Z = Zdata
eigZ = eigen(t(Z)%*%Z)
EZ = eigZ$vectors[,2:K]
EPC = Z%*%EZ

y = ydata;

Xsca = sqrt(colSums(Xdata*Xdata))/sqrt(n)
X = Xdata/(matrix(1, nrow = n, ncol = 1)%*%Xsca)

Esca = sqrt(colSums(EPC*EPC))/sqrt(n)
EPCb = EPC/(matrix(1, nrow = n, ncol = 1)%*%Esca)

Xf = cbind(X,EPCb)
pf = p + K - 1

print(paste("X row",toString(nrow(X)),"col",toString(ncol(X)),"",sep=" "))
print(paste("Xf row",toString(nrow(Xf)),"col",toString(ncol(Xf)),"",sep=" "))

objX = isee(X, regfactor, npermu, sis.use, bia.cor) 
OmegaX = objX$Omega.isee
Xnew = gknockoffX(X, OmegaX)

objXf = isee(Xf, regfactor, npermu, sis.use, bia.cor) 
OmegaXf = objXf$Omega.isee
Xfnew = gknockoffX(Xf, OmegaXf)

obj1X = slassotf(Xnew, y, regfactor, sis.use = 0)
betap.stanX = obj1X$betap.stan

obj1Xf = slassotf(Xfnew, y, regfactor, sis.use = 0)
betap.stanXf = obj1Xf$betap.stan


write.table(Xnew, file="data/X_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(Xfnew, file="data/Xf_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(y, file="data/Y.csv",row.names=FALSE, col.names=FALSE, sep=",")


write.table(betap.stanX, file="data/w_slassotf_X_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(betap.stanXf, file="data/w_slassotf_Xf_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")

p=ncol(X);
W = c(rep(0, p))
for (j in 1:p) {
  W[j] = abs(betap.stanX[j]) - abs(betap.stanX[j+p])
}

t = sort(c(0, abs(W)))
ratio = c(rep(0, p))
for (j in 1:p) {
  ratio[j] = sum(W <= -t[j])/max(1, sum(W >= t[j]))
}
id = which(ratio <= q)[1]
if(length(id) == 0){
  T = Inf
} else {
  T = t[id]
}
S = which(W >= T);
write.table(S, file="data/S_slassotf_X_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")

p=ncol(Xf);
W = c(rep(0, p))
for (j in 1:p) {
  W[j] = abs(betap.stanXf[j]) - abs(betap.stanXf[j+p])
}

t = sort(c(0, abs(W)))
ratio = c(rep(0, p))
for (j in 1:p) {
  ratio[j] = sum(W <= -t[j])/max(1, sum(W >= t[j]))
}
id = which(ratio <= q)[1]
if(length(id) == 0){
  T = Inf
} else {
  T = t[id]
}
Sf = which(W >= T);
write.table(Sf, file="data/S_slassotf_Xf_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")







