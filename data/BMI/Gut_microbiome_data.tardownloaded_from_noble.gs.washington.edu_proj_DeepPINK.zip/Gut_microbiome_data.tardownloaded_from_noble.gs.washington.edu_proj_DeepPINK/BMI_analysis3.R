setwd("/home/yanglu/Documents/deepknockoff/data/2018-03-18/microbiome")


source('/home/yanglu/Documents/deepknockoff/src/RANK/gknockoff_all.R')
#source('/home/yanglu/Documents/deepknockoff/src/RANK/gknockoff_all_emre.R')
source('/home/yanglu/Documents/deepknockoff/src/RANK/isee_all.R')


require(graphics)
library(MASS) 
library(Matrix)
library(pracma)

library(foreach)
library(glmnet)
library(lars)
library(scalreg)

set.seed(100)
q = 0.2
regfactor = "log"
npermu = 5
sis.use = 0
bia.cor = 0


Xdataraw = as.matrix(read.table("data/nutrient_intake.txt"))
Zdataraw = as.matrix(read.table("data/miocrobiome_cenlograc.txt"))
ydataraw = as.matrix(read.table("data/bmi.txt"))

#remove the outlier
set = union(1:17,19:98)
#focus on the non-thin ones
set = setdiff(set, which(ydataraw - mean(ydataraw)< -6))
Xdata = Xdataraw[set,]
Zdata = Zdataraw[set,]
ydata = t(t(ydataraw[set]))
#dim(ydata)

n = nrow(Xdata)
p = ncol(Xdata)


R = cor(Xdata)
L = lower.tri(R, diag = T)
R[L] = 0
sub = c()
for (i in 1:(p - 1)) {
   if (is.element(i, sub)){}
   else
     {sub = union(sub, which(R[i,] > 0.9))}
}
supp = setdiff(1:p, sub)
XSubdata = Xdata[,supp]




y = ydata;

Xsca = sqrt(colSums(Xdata*Xdata))/sqrt(n)
X = Xdata/(matrix(1, nrow = n, ncol = 1)%*%Xsca)

XSubsca = sqrt(colSums(XSubdata*XSubdata))/sqrt(n)
Xsub = XSubdata/(matrix(1, nrow = n, ncol = 1)%*%XSubsca)

Zsca = sqrt(colSums(Zdata*Zdata))/sqrt(n)
Z = Zdata/(matrix(1, nrow = n, ncol = 1)%*%Zsca)

XZ = cbind(X,Z)
XsubZ = cbind(Xsub,Z)


print(paste("X row",toString(nrow(X)),"col",toString(ncol(X)),"",sep=" "))
print(paste("Xsub row",toString(nrow(Xsub)),"col",toString(ncol(Xsub)),"",sep=" "))
print(paste("Z row",toString(nrow(Z)),"col",toString(ncol(Z)),"",sep=" "))
print(paste("XZ row",toString(nrow(XZ)),"col",toString(ncol(XZ)),"",sep=" "))
print(paste("XsubZ row",toString(nrow(XsubZ)),"col",toString(ncol(XsubZ)),"",sep=" "))

objX = isee(X, regfactor, npermu, sis.use, bia.cor) 
OmegaX = objX$Omega.isee
Xnew = gknockoffX(X, OmegaX)

objXsub = isee(Xsub, regfactor, npermu, sis.use, bia.cor) 
OmegaXsub = objXsub$Omega.isee
Xsubnew = gknockoffX(Xsub, OmegaXsub)

objZ = isee(Z, regfactor, npermu, sis.use, bia.cor) 
OmegaZ = objZ$Omega.isee
Znew = gknockoffX(Z, OmegaZ)

objXZ = isee(XZ, regfactor, npermu, sis.use, bia.cor) 
OmegaXZ = objXZ$Omega.isee
XZnew = gknockoffX(XZ, OmegaXZ)

objXsubZ = isee(XsubZ, regfactor, npermu, sis.use, bia.cor) 
OmegaXsubZ = objXsubZ$Omega.isee
XsubZnew = gknockoffX(XsubZ, OmegaXsubZ)


write.table(Xnew, file="data/X_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(Xsubnew, file="data/Xsub_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(Znew, file="data/Z_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(XZnew, file="data/XZ_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(XsubZnew, file="data/XsubZ_knockoff.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(y, file="data/Y.csv",row.names=FALSE, col.names=FALSE, sep=",")
write.table(supp, file="data/subXIdx.txt",row.names=FALSE, col.names=FALSE, sep=",")


