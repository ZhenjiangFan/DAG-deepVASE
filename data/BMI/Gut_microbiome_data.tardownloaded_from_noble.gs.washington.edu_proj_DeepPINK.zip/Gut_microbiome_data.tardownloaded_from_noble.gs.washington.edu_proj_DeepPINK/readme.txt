otu.tab: the species-level OTU table, you may need some filtering to remove rare OTUs
tree: phylogenetic tree
ffq.raw: the intake amount of 214 nutrients w/o adjusting the total caloric intake
ffq.adj: the intake amount of 214 nutrients w/ adjusting the total caloric intake (this is what we used in the analysis)
abund.list: a list of abundance tables at higher taxonomic levels (phylum to genus)
demo: demographic table
bmi.c: BMI
